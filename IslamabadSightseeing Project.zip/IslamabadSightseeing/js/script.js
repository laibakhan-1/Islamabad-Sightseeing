// Wait for DOM to load
document.addEventListener('DOMContentLoaded', () => {

  // 1. Mobile Menu Toggle (for navbar)
  const menuToggle = document.getElementById('menu-toggle');
  const navbar = document.getElementById('navbar');

  if (menuToggle && navbar) {
    menuToggle.addEventListener('click', () => {
      navbar.classList.toggle('active'); // toggle 'active' class to show/hide menu
    });
  }

  // 2. Form Validation: Number of People >= 1
  const bookingForms = document.querySelectorAll('form[action="php/book_tour.php"]');

  bookingForms.forEach(form => {
    form.addEventListener('submit', (e) => {
      const peopleInput = form.querySelector('input[name="people"]');
      if (!peopleInput || peopleInput.value < 1) {
        alert('Please enter a valid number of people (minimum 1).');
        e.preventDefault();
        peopleInput.focus();
      }
    });
  });

  // 3. Smooth Scroll for internal links (optional)
  const internalLinks = document.querySelectorAll('a[href^="#"]');
  internalLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
        targetElement.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  // 4. Back to Top Button (optional)
  const backToTopBtn = document.createElement('button');
  backToTopBtn.textContent = '↑';
  backToTopBtn.id = 'back-to-top';
  backToTopBtn.style.cssText = `
    position: fixed;
    bottom: 30px;
    right: 30px;
    background-color: #1976d2;
    color: white;
    border: none;
    padding: 12px 16px;
    border-radius: 50%;
    font-size: 1.5rem;
    cursor: pointer;
    display: none;
    box-shadow: 0 4px 12px rgba(25, 118, 210, 0.6);
    z-index: 1000;
  `;
  document.body.appendChild(backToTopBtn);

  backToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
      backToTopBtn.style.display = 'block';
    } else {
      backToTopBtn.style.display = 'none';
    }
  });

});
