<?php
session_start();
include('config.php'); // $pdo should be defined here

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Fetch packages for booking options
try {
    $stmt = $pdo->query("SELECT * FROM packages");
    $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error = "Error fetching packages: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $package_id = intval($_POST['package_id'] ?? 0);
    $booking_date = $_POST['booking_date'] ?? '';
    $time_slot = $_POST['time_slot'] ?? '';
    $number_of_people = intval($_POST['num_people'] ?? 0);

    // Basic validation
    if (!$package_id || !$booking_date || !$time_slot || $number_of_people < 1) {
        $error = "Please fill all fields correctly.";
    } else {
        // Fetch package price
        $stmt = $pdo->prepare("SELECT price FROM packages WHERE id = ?");
        $stmt->execute([$package_id]);
        $package = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$package) {
            $error = "Invalid package selected.";
        } else {
            $total_amount = $package['price'] * $number_of_people;
            $status = 'pending'; // default status

            $insertStmt = $pdo->prepare("INSERT INTO bookings (user_id, package_id, booking_date, time_slot, number_of_people, total_amount, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $successInsert = $insertStmt->execute([$user_id, $package_id, $booking_date, $time_slot, $number_of_people, $total_amount, $status]);

            if ($successInsert) {
                // Redirect to mybookings.php after successful booking
                header("Location: mybookings.php");
                exit();
            } else {
                $error = "Booking failed. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Booking - Islamabad Sightseeing</title>
  <style>
    /* Color theme: sky blue, white, blue */
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #e1f0fb;
      color: #0d47a1;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 20px;
    }
    nav {
      width: 100%;
      max-width: 1200px;
      background-color: #1976d2;
      border-radius: 12px;
      padding: 12px 24px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.15);
      margin-bottom: 40px;
      display: flex;
      align-items: center;
      color: white;
      font-weight: 700;
      font-size: 1.5rem;
      user-select: none;
    }
    main {
      background: white;
      max-width: 480px;
      width: 100%;
      border-radius: 16px;
      padding: 40px 32px;
      box-shadow: 0 6px 20px rgba(25, 118, 210, 0.3);
    }
    h1 {
      margin-top: 0;
      margin-bottom: 36px;
      font-weight: 700;
      font-size: 2.2rem;
      text-align: center;
      color: #0d47a1;
    }
    form label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
      color: #1565c0;
      margin-top: 20px;
    }
    form select,
    form input[type="date"],
    form input[type="number"] {
      width: 100%;
      padding: 10px 14px;
      border-radius: 10px;
      border: 2px solid #90caf9;
      font-size: 1rem;
      color: #0d47a1;
      background-color: #e3f2fd;
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
    form select:focus,
    form input[type="date"]:focus,
    form input[type="number"]:focus {
      outline: none;
      border-color: #0d47a1;
      box-shadow: 0 0 8px #0d47a1aa;
      background-color: #ffffff;
    }
    button[type="submit"] {
      margin-top: 32px;
      width: 100%;
      padding: 14px 0;
      background-color: #1976d2;
      color: white;
      font-weight: 700;
      font-size: 1.2rem;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      box-shadow: 0 4px 12px #1565c0aa;
      transition: background-color 0.3s ease;
    }
    button[type="submit"]:hover {
      background-color: #0d47a1;
      box-shadow: 0 6px 18px #0b3d91cc;
    }
    .message {
      font-weight: 700;
      padding: 12px 20px;
      border-radius: 10px;
      margin-bottom: 24px;
      text-align: center;
      box-shadow: 0 0 12px rgba(0,0,0,0.1);
    }
    .error {
      background-color: #ffcdd2;
      color: #d32f2f;
      box-shadow: 0 0 15px #d32f2f66;
    }
    .success {
      background-color: #c8e6c9;
      color: #2e7d32;
      box-shadow: 0 0 15px #2e7d3266;
    }
    @media (max-width: 520px) {
      main {
        padding: 30px 20px;
      }
      h1 {
        font-size: 1.8rem;
        margin-bottom: 28px;
      }
    }
  </style>
</head>
<body>
  <nav>
    Islamabad Sightseeing
  </nav>
  <main>
    <h1>Book a Tour Package</h1>

    <?php if ($error): ?>
      <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
      <div class="message success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" action="booking.php" novalidate>
      <label for="package_id">Select Package</label>
      <select name="package_id" id="package_id" required>
        <option value="">--Choose a package--</option>
        <?php foreach ($packages as $row): ?>
          <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['title']) ?> - Rs <?= number_format($row['price']) ?></option>
        <?php endforeach; ?>
      </select>

      <label for="booking_date">Date</label>
      <input type="date" name="booking_date" id="booking_date" required min="<?= date('Y-m-d') ?>">

      <label for="time_slot">Time Slot</label>
      <select name="time_slot" id="time_slot" required>
        <option value="">--Select a time slot--</option>
        <option value="10:00 AM - 12:00 PM">10:00 AM - 12:00 PM</option>
        <option value="12:30 PM - 2:30 PM">12:30 PM - 2:30 PM</option>
        <option value="3:00 PM - 5:00 PM">3:00 PM - 5:00 PM</option>
      </select>

      <label for="num_people">Number of People</label>
      <input type="number" name="num_people" id="num_people" min="1" max="20" value="1" required>

      <button type="submit">Confirm Booking</button>
    </form>
  </main>
  <footer style="margin-top: 40px; color: #0d47a1; font-weight: 600;">
    &copy; <?= date('Y') ?> Islamabad Sightseeing
  </footer>
</body>
</html>