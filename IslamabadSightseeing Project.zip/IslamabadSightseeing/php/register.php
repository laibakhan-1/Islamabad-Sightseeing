<?php
include 'config.php';
session_start();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($name) || empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "Please fill all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email or username already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        if ($stmt->fetch()) {
            $error = "Email or Username already taken.";
        } else {
            // Insert new user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, username, email, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $username, $email, $hashed_password]);

            $success = "Registration successful! You can now <a href='login.php'>login</a>.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Register - Islamabad Sightseeing</title>
  <style>
    body {
      background-color: #e3f2fd; /* Light accessible blue */
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #0d47a1;
      min-height: 100vh;
    }
    a {
      text-decoration: none;
      color: inherit;
    }
    /* Navbar */
    nav {
      background-color: #1976d2; /* Dark blue */
      padding: 0 24px;
      display: flex;
      align-items: center;
      height: 60px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.15);
      max-width: 1200px;
      margin: 20px auto 0 auto;
      border-radius: 12px;
    }
    nav .brand {
      font-weight: 700;
      font-size: 1.5rem;
      color: #fff;
      flex-shrink: 0;
    }
    nav ul {
      list-style: none;
      display: flex;
      gap: 18px;
      margin-left: auto;
      padding-left: 0;
    }
    nav ul li a {
      color: #bbdefb; /* Light blue text */
      font-weight: 600;
      padding: 8px 12px;
      border-radius: 6px;
      transition: background-color 0.3s ease, color 0.3s ease;
      display: block;
    }
    nav ul li a.active,
    nav ul li a:hover {
      background-color: #0d47a1; /* Darker blue */
      color: #fff;
    }

    /* Main container */
    main {
      max-width: 500px;
      margin: 60px auto 60px auto;
      padding: 40px 32px;
      background-color: #fff;
      border-radius: 16px;
      box-shadow: 0 4px 18px rgba(0,0,0,0.1);
    }
    h1.page-title {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 36px;
      text-align: center;
      color: #0d47a1;
    }
    form label {
      display: block;
      font-weight: 600;
      margin-bottom: 6px;
      color: #0d47a1;
    }
    form input {
      width: 100%;
      padding: 10px 12px;
      margin-bottom: 20px;
      border: 1.5px solid #1976d2;
      border-radius: 10px;
      font-size: 1rem;
      box-sizing: border-box;
      color: #0d47a1;
      background: #fff;
      transition: border-color 0.3s ease;
    }
    form input:focus {
      outline: none;
      border-color: #0d47a1;
      box-shadow: 0 0 5px #0d47a1aa;
    }
    button[type="submit"] {
      width: 100%;
      padding: 12px 0;
      background-color: #1976d2;
      border: none;
      border-radius: 12px;
      color: white;
      font-weight: 700;
      font-size: 1.1rem;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button[type="submit"]:hover {
      background-color: #0d47a1;
    }
    p.login-link {
      text-align: center;
      margin-top: 20px;
      font-size: 1rem;
      color: #0d47a1;
    }
    p.login-link a {
      color: #1976d2;
      font-weight: 600;
    }
    p.login-link a:hover {
      text-decoration: underline;
    }

    /* Responsive */
    @media (max-width: 600px) {
      main {
        margin: 40px 12px 40px 12px;
        padding: 30px 20px;
      }
      h1.page-title {
        font-size: 1.6rem;
        margin-bottom: 28px;
      }
    }
  </style>
</head>
<body>
  <nav>
    <div class="brand">Islamabad Sightseeing</div>
    <ul>
      <li><a href="index.html">Home</a></li>
      <li><a href="attractions.html">Attractions</a></li>
      <li><a href="itineraries.html">Itineraries</a></li>
      <li><a href="packages.php">Packages</a></li>
      <li><a href="gallery.html">Gallery</a></li>
      <li><a href="contact.html">Contact</a></li>
      <li><a href="login.html">Login</a></li>
      <li><a href="register.html" class="active">Register</a></li>
    </ul>
  </nav>

  <main>
    <h1 class="page-title">Create an Account</h1>
    <form action="login.php" method="POST" novalidate>
      <label for="fullname">Full Name</label>
      <input type="text" name="fullname" id="fullname" placeholder="Enter your full name" required>

      <label for="email">Email Address</label>
      <input type="email" name="email" id="email" placeholder="Enter your email" required>

      <label for="username">Username</label>
      <input type="text" name="username" id="username" placeholder="Choose a username" required>

      <label for="password">Password</label>
      <input type="password" name="password" id="password" placeholder="Create a password" required>

      <button type="submit">Register</button>
    </form>
    <p class="login-link">Already have an account? <a href="login.php">Login here</a></p>
  </main>
</body>
</html>
