<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: ../login.html");
    exit();
}
include('../php/db.php');

// Handle Add Package
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_package'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $query = "INSERT INTO packages (name, description, price) VALUES ('$name', '$description', '$price')";
    mysqli_query($conn, $query);
    header("Location: manage_packages.php");
    exit();
}

// Handle Delete Package
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $query = "DELETE FROM packages WHERE id = $id";
    mysqli_query($conn, $query);
    header("Location: manage_packages.php");
    exit();
}

// Fetch Packages
$query = "SELECT * FROM packages";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Packages - Admin Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
    background-color: skyblue;
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
    .navbar {
      background-color: #343a40;
    }
    .navbar-brand, .nav-link {
      color: #fff !important;
      font-weight: bold;
    }
    .container {
      margin-top: 80px;
    }
    .table th, .table td {
      vertical-align: middle;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar fixed-top navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand" href="#">Admin Panel</a>
    <div class="ms-auto">
      <span class="text-white me-3">Admin: <?php echo $_SESSION['admin']; ?></span>
      <a href="../php/logout.php" class="btn btn-light btn-sm">Logout</a>
    </div>
  </div>
</nav>

<!-- Main Content -->
<div class="container">
  <h2 class="mb-4">Manage Tour Packages</h2>

  <!-- Add Package Form -->
  <div class="card mb-4">
    <div class="card-header">Add New Package</div>
    <div class="card-body">
      <form method="POST" action="">
        <div class="mb-3">
          <label for="name" class="form-label">Package Name</label>
          <input type="text" class="form-control" name="name" id="name" required>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description</label>
          <textarea class="form-control" name="description" id="description" rows="3" required></textarea>
        </div>
        <div class="mb-3">
          <label for="price" class="form-label">Price (PKR)</label>
          <input type="number" class="form-control" name="price" id="price" required>
        </div>
        <button type="submit" name="add_package" class="btn btn-primary">Add Package</button>
      </form>
    </div>
  </div>

  <!-- Packages Table -->
  <table class="table table-bordered">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Package Name</th>
        <th>Description</th>
        <th>Price (PKR)</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($result)): ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo htmlspecialchars($row['name']); ?></td>
        <td><?php echo htmlspecialchars($row['description']); ?></td>
        <td><?php echo $row['price']; ?></td>
        <td>
          <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this package?');">Delete</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
