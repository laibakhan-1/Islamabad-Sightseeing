<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch bookings of the logged-in user
$sql = "SELECT b.*, p.title AS package_title 
        FROM bookings b
        LEFT JOIN packages p ON b.package_id = p.id
        WHERE b.user_id = ?
        ORDER BY b.booking_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>My Bookings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f4f7fa;
            min-height: 100vh;
        }
        .container {
            max-width: 900px;
            background: #ffffff;
            padding: 2.5rem 2rem;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            margin-top: 3rem;
            margin-bottom: 3rem;
        }
        h2 {
            font-weight: 700;
            color: #1565c0;
            margin-bottom: 1.5rem;
            text-align: center;
            letter-spacing: 1px;
        }
        table.table {
            box-shadow: 0 2px 12px rgba(21, 101, 192, 0.15);
            border-radius: 8px;
            overflow: hidden;
        }
        table.table thead {
            background-color: #1565c0;
            color: #fff;
        }
        table.table thead th {
            border: none;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
        }
        table.table tbody tr:hover {
            background-color: #e3f2fd;
        }
        table.table tbody td {
            vertical-align: middle;
            text-align: center;
        }
        .badge {
            font-size: 0.9rem;
            padding: 0.45em 0.8em;
            border-radius: 12px;
        }
        a.btn-secondary {
            display: inline-block;
            margin-top: 1.8rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: background-color 0.3s ease;
        }
        a.btn-secondary:hover {
            background-color: #0d47a1;
            color: #fff;
        }
        @media (max-width: 576px) {
            .container {
                padding: 1.5rem 1rem;
                margin: 1.5rem 1rem 2rem;
            }
            h2 {
                font-size: 1.75rem;
            }
            table.table thead th,
            table.table tbody td {
                font-size: 0.85rem;
                padding: 0.5rem 0.3rem;
            }
            a.btn-secondary {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container shadow-sm">
        <h2>My Bookings</h2>

        <?php if (count($bookings) === 0): ?>
            <div class="alert alert-info text-center fs-5">You have no bookings yet.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Package Title</th>
                            <th>Date</th>
                            <th>Time Slot</th>
                            <th>People</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?= htmlspecialchars($booking['id']) ?></td>
                                <td><?= htmlspecialchars($booking['package_title'] ?? 'Unknown') ?></td>
                                <td><?= htmlspecialchars(date('F j, Y', strtotime($booking['booking_date']))) ?></td>
                                <td><?= htmlspecialchars($booking['time_slot'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($booking['people'] ?? 'N/A') ?></td>
                                <td>
                                    <?php 
                                    $status = strtolower($booking['status'] ?? 'pending');
                                    if ($status === 'accepted') {
                                        echo '<span class="badge bg-success">Accepted</span>';
                                    } elseif ($status === 'rejected') {
                                        echo '<span class="badge bg-danger">Rejected</span>';
                                    } else {
                                        echo '<span class="badge bg-warning text-dark">Pending</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <a href="../index.html" class="btn btn-secondary">Back to Home</a>
    </div>
</body>
</html>
